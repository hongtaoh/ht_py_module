from setuptools import setup, find_packages

setup(
    name="ht_py_module",
    version="0.1",
    packages=find_packages(),
    description="A very simple example module",
    author="Jason Dsouza, ChatGPT, and Hongtao Hao",
    author_email="hhao9@wisc.edu",
    url="",
    install_requires=[
        # add any additional packages that 
        # needs to be installed along with your package. Eg: 'pandas'
    ],
)
